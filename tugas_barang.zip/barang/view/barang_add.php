<?php include("header.php"); ?>

<h2>Tambah Barang</h2>
<form method="post">
    Kode Barang: <input type="text" name="kode_barang"><br>
    Nama Barang: <input type="text" name="nama_barang"><br>
    <button type="submit">Simpan</button>
</form>

<?php include("footer.php"); ?>
