<nav>
    <a href="index.php?page=dashboard">Dashboard</a> |
    <a href="index.php?page=barang">Data Barang</a>
</nav>
<hr>
