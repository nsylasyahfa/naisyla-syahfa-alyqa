<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" type="text/css" href="style.css">
        <title>MVC Barang</title>
    </head>
    <body>
        
        <?php include("menu.php"); ?>
