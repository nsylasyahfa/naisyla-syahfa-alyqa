<?php include("header.php"); ?>

<h2>Selamat Datang di Dashboard</h2>
<p>Silakan pilih menu di atas untuk mengelola data barang.</p>

<?php include("footer.php"); ?>
