<?php include('./view/layout/header.php'); ?>

<div class="container">
    <div class="card">
        <h2>Selamat Datang 👋</h2>
        <p>Selamat datang di sistem informasi perpustakaan. Silakan gunakan menu untuk mengelola data buku, anggota, dan transaksi.</p>
    </div>
</div>

<?php include('./view/layout/footer.php'); ?>
