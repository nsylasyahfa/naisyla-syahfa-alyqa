<?php include('./view/layout/header.php'); ?>

<div class="row">
    <div class="col-lg-12">
        <h4 class="mb-3">Buku</h4>
        <div class="card">
            <div class="card-header">
                <a href="index.php?modul=buku&proses=tambah" class="btn btn-primary">Tambah Buku</a>
            </div>
            <div class="card-body">
                <?php
                if(isset($_SESSION["ERROR_SISTEM"])){
                    echo '<div class="alert alert-danger" role="alert">'.$_SESSION["ERROR_SISTEM"].'</div>';
                    unset($_SESSION["ERROR_SISTEM"]);
                }

                if(isset($_SESSION["SUCCESS_SISTEM"])){
                    echo '<div class="alert alert-success" role="alert">'.$_SESSION["SUCCESS_SISTEM"].'</div>';
                    unset($_SESSION["SUCCESS_SISTEM"]);
                }
                ?>
                <table class="table table-bordered table-sm">
                    <thead>
                        <th>No.</th>
                        <th>Kode</th>
                        <th>ISBN</th>
                        <th>Judul</th>
                        <th>Pengarang</th>
                        <th>Tahun</th>
                        <th>Penerbit</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>
                        <?php 
                        $i=1;
                        foreach($data_buku as $buku): ?>
                        <tr>
                            <td><?=$i?></td>
                            <td><?=$buku['kode_buku']?></td>
                            <td><?=$buku['isbn']?></td>
                            <td><?=$buku['judul']?></td>
                            <td><?=$buku['pengarang']?></td>
                            <td><?=$buku['tahun']?></td>
                            <td><?=$buku['penerbit']?></td>
                            <td><?=$buku['status']?></td>
                            <td>
                                <a href="index.php?modul=buku&proses=ubah&kode=<?=$buku['kode_buku']?>" class="btn btn-sm btn-success">Edit</a> | <a href="index.php?modul=buku&proses=proses_hapus&kode=<?=$buku['kode_buku']?>" class="btn btn-sm btn-danger">Hapus</a>
                            </td>
                        </tr>
                        <?php 
                        $i+=1;
                        endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
    </div>
</div>

<?php include('./view/layout/footer.php'); ?>