<?php include('./view/layout/header.php'); ?>

<div class="row">
    <div class="col-lg-12">
        <h4 class="mb-3">Anggota</h4>
        <div class="card">
            <div class="card-header">
                <a href="index.php?modul=anggota&proses=tambah" class="btn btn-primary">Tambah Anggota</a>
            </div>
            <div class="card-body">
                <?php
                if(isset($_SESSION["ERROR_SISTEM"])){
                    echo '<div class="alert alert-danger" role="alert">'.$_SESSION["ERROR_SISTEM"].'</div>';
                    unset($_SESSION["ERROR_SISTEM"]);
                }

                if(isset($_SESSION["SUCCESS_SISTEM"])){
                    echo '<div class="alert alert-success" role="alert">'.$_SESSION["SUCCESS_SISTEM"].'</div>';
                    unset($_SESSION["SUCCESS_SISTEM"]);
                }
                ?>
                <table class="table table-bordered table-sm">
                    <thead>
                        <th>No.</th>
                        <th>NPM</th>
                        <th>Nama</th>
                        <th>Jurusan</th>
                        <th>No Telp</th>
                        <th>Email</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>
                        <?php 
                        $i=1;
                        foreach($data_anggota as $anggota): ?>
                        <tr>
                            <td><?=$i?></td>
                            <td><?=$anggota['npm']?></td>
                            <td><?=$anggota['nama']?></td>
                            <td><?=$anggota['jurusan']?></td>
                            <td><?=$anggota['no_telp']?></td>
                            <td><?=$anggota['email']?></td>
                            <td>
                                <a href="index.php?modul=anggota&proses=ubah&npm=<?=$anggota['npm']?>" class="btn btn-sm btn-success">Edit</a> | <a href="index.php?modul=anggota&proses=proses_hapus&npm=<?=$anggota['npm']?>" class="btn btn-sm btn-danger">Hapus</a>
                            </td>
                        </tr>
                        <?php 
                        $i+=1;
                        endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
    </div>
</div>

<?php include('./view/layout/footer.php'); ?>