<!DOCTYPE html>
<html class="h-100">
    <head>
        <link rel="stylesheet" href="<?php echo dirname($_SERVER['PHP_SELF'], 2); ?>/style.css">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Sistem Perpustakaan</title>
        <link rel="stylesheet" href="./addon/bootstrap/css/bootstrap.min.css">
        <script src="./addon/jquery.js"></script>
        <script src="./addon/bootstrap/js/bootstrap.bundle.min.js"></script>
    </head>
    <body class="h-100">
        <?php include('./view/layout/menu.php'); ?>
        <div class="container">

