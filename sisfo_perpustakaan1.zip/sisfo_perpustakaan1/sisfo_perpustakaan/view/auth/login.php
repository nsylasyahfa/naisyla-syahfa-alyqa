<!DOCTYPE html>
<html lang="id" class="h-100">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Sistem Perpustakaan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="h-100 login-page">

    <div class="login-wrapper">
        <div class="login-card">
            <h2 class="login-title">🔐 Login</h2>
            <?php
            if (isset($_SESSION["ERROR_SISTEM"])) {
                echo '<div class="login-alert error">' . $_SESSION["ERROR_SISTEM"] . '</div>';
                unset($_SESSION["ERROR_SISTEM"]);
            }
            ?>
            <p class="login-subtitle">Silakan login untuk mengakses sistem</p>

            <form action="index.php?modul=auth&proses=vlogin" method="post" class="login-form">
                <label for="username">👤 Username</label>
                <input type="text" name="username" id="username" required>

                <label for="password">🔒 Password</label>
                <input type="password" name="password" id="password" required>

                <button type="submit">🚀 Masuk</button>
            </form>
        </div>
    </div>

</body>
</html>
